JAHID DAIRY AI - Android Studio Project

এই ফোল্ডারটি Android Studio-তে খুলে APK তৈরি করা যাবে।
১) Android Studio ইনস্টল করুন।
২) Android Studio > Open > এই JahidDairyAI ফোল্ডার নির্বাচন করুন।
৩) Gradle Sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
৪) APK তৈরি হলে Android Studio-র notification থেকে Locate চাপুন।
৫) APK ফোনে পাঠিয়ে ইনস্টল করুন।

ফিচার:
- মালিকের নাম, মোবাইল, ঠিকানা
- গাভীর জাত
- বীজের ধরন ও নম্বর
- বীজ দেওয়ার তারিখ
- ২১ দিনের পর্যবেক্ষণ কাউন্টডাউন
- সার্চ, সম্পাদনা ও মুছে ফেলা
- তথ্য ফোনের লোকাল স্টোরেজে থাকে
- কোনো টাকা-পয়সার হিসাব নেই

নোট: এই পরিবেশে Android SDK/Gradle নেই, তাই APK সরাসরি কম্পাইল করা যায়নি।
